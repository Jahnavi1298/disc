package com.example.asdfg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.asdfg.entity.Discount;
import com.example.asdfg.exception.DiscountException;
import com.example.asdfg.service.AdminServices;


@CrossOrigin()
@RestController

public class AdminActionController {
	@Autowired
     AdminServices adminService;
	
	@PostMapping("/adddiscount")
	public List<Discount> CreateDiscount(@RequestBody Discount discount) 
	{
		return adminService.CreateDiscount(discount);
	}
	
	
		@GetMapping("/productbyId/{id}")
	public Discount getProductById(@PathVariable int id) throws DiscountException{
	    return adminService.getproductById(id);
	    }
	
	
 @GetMapping("/productbyprice/{price}")
    public List<Discount> getProductByPrice(@PathVariable int price) throws DiscountException{
       return adminService.getProductByPrice(price);
    }
}

