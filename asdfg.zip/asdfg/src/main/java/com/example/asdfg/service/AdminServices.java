package com.example.asdfg.service;

import java.util.List;

import com.example.asdfg.entity.Discount;
import com.example.asdfg.exception.DiscountException;



public interface AdminServices {

	public List<Discount> CreateDiscount(Discount discount);

	public List<Discount> getProductByPrice(int price) throws DiscountException;


	 public Discount getproductById(int id) throws DiscountException;
	
}
