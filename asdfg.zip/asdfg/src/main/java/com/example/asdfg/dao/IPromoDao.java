package com.example.asdfg.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.asdfg.entity.Discount;







@Repository
public interface IPromoDao extends JpaRepository<Discount,Integer>{

	Optional<Discount> findById(int id);

	List<Discount> findByPrice(int price);
	

}