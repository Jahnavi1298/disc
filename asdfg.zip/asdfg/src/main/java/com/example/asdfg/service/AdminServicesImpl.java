package com.example.asdfg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.asdfg.dao.IPromoDao;
import com.example.asdfg.entity.Discount;
import com.example.asdfg.exception.DiscountException;


@Service
@Transactional
public class AdminServicesImpl implements AdminServices {
@Autowired
		IPromoDao promoDao;

@Override
public List<Discount> CreateDiscount(Discount discount) {
	if(discount.getPrice()>2000)
	{
	String temp = "Your Discount is 20%";
	discount.setDiscount(temp);
	float discountAmount = (discount.getPrice()*20)/100;
	float discountPrice = discount.getPrice()-discountAmount;
	discount.setFinalPrice(discountPrice);
	promoDao.save(discount);
	}
	else
	{
		float discountAmount = (float) ((discount.getPrice()*0.5)/100);
		float discountPrice = discount.getPrice()-discountAmount;
		discount.setFinalPrice(discountPrice);
		promoDao.save(discount);
		
	}
	return promoDao.findAll();
	
}

@Override
public Discount getproductById(int id) throws DiscountException {
	
	try {
        return promoDao.findById(id).get();
    }
    catch(Exception ex)
    {
    	throw new DiscountException(ex.getMessage()+" No product with this id"+ id);
    }
}

@Override
public List<Discount> getProductByPrice(int price) throws DiscountException {
	
	 try
	 	{
			return promoDao.findByPrice(price);
     }
     catch(Exception ex)
     {
     	throw new DiscountException(ex.getMessage()+" No product greater than this price "+ price);
     }
	
}
}


		
		


